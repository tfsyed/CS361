	public enum instruction_type{READ, WRITE, BAD};
